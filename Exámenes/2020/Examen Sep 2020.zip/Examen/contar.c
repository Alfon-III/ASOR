#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/mman.h>

volatile int iterrupt;
volatile int stop;

void handler(int sig){
	if(sig == SIGINT){
		iterrupt++;
	}
	else{
		stop++;
	}
}

int
main() {

	struct sigaction sa;

	sa.sa_flags = SA_SIGINFO;
	sigemptyset(&sa.sa_mask);
	sa.sa_sigaction = handler;

	if (sigaction(SIGINT, &sa, NULL) == -1){
		perror("Sigaction()");
	}
	if (sigaction(SIGTSTP, &sa, NULL) == -1){
		perror("Sigaction()");
	}

	sigset_t set;

	sigemptyset(&set);
	while(iterrupt + stop < 10)
		sigsuspend(&set);

	printf("[SIGINT]%li\n", iterrupt);
	printf("[SIGSTP]%li\n", stop);

	return 0;

}